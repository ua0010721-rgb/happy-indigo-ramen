
                  import React, { useState, useEffect, createContext, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, FlatList, StyleSheet, SafeAreaView, ScrollView } from 'react-native';

/*
  Snack-ready single file demo that simulates a "Maza-like" app main features:
  - Login (local mock)
  - Tabbed UI (Home, Recharge, Rooms, Profile, Admin)
  - Diamond recharge, SVIP purchases, create rooms, matchmaking
  - Simple admin controls (give SVIP, ban user)
  - Mock data + persistent local state (in-memory for Snack simplicity)

  This is intended as a starting, snack-compatible file. You can paste your real components later.
*/

const initialUser = {
  id: 'user_' + Math.floor(Math.random() * 10000),
  name: 'Guest',
  diamonds: 5000,
  beans: 0,
  svip: 0,
  levelExp: 0,
  isAdmin: false,
  banned: false,
};

const AppContext = createContext();

function useApp() {
  return useContext(AppContext);
}

function LoginScreen() {
  const { user, setUser } = useApp();
  const [name, setName] = useState('');

  function login() {
    if (!name.trim()) return Alert.alert('Enter name');
    setUser(prev => ({ ...prev, name: name.trim() }));
  }

  return (
    <View style={styles.containerCenter}>
      <Text style={styles.h1}>Welcome to Maza Demo</Text>
      <TextInput placeholder="Enter display name" value={name} onChangeText={setName} style={styles.input} />
      <TouchableOpacity onPress={login} style={styles.btnPrimary}>
        <Text style={styles.btnText}>Set Name & Continue</Text>
      </TouchableOpacity>
      <Text style={{ marginTop: 20 }}>You can use the in-app demo features. This is a mockup.</Text>
      <Text style={{ marginTop: 6, fontSize: 12, color: '#666' }}>User id: {user.id}</Text>
    </View>
  );
}

function TopBar() {
  const { user } = useApp();
  return (
    <View style={styles.topbar}>
      <Text style={{ fontWeight: '700' }}>{user.name}</Text>
      <Text>Diamonds: {user.diamonds}</Text>
      <Text>SVIP: {user.svip}</Text>
    </View>
  );
}

function HomeTab() {
  const { user, sendGift } = useApp();
  return (
    <ScrollView style={{ flex: 1, padding: 12 }}>
      <Text style={styles.h2}>Home</Text>
      <Text>Welcome back, {user.name}! Your level EXP: {user.levelExp}</Text>

      <View style={{ marginTop: 12 }}>
        <Text style={{ fontWeight: '700' }}>Quick Actions</Text>
        <TouchableOpacity style={styles.action} onPress={() => sendGift(1000)}>
          <Text>Send Gift (1,000 diamonds) — increases EXP</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.action} onPress={() => sendGift(5000)}>
          <Text>Send Big Gift (5,000 diamonds)</Text>
        </TouchableOpacity>
      </View>

      <View style={{ marginTop: 12 }}>
        <Text style={styles.h3}>Top Rooms (mock)</Text>
        <Text>• Lucky Room — Target 100k</Text>
        <Text>• Party Room — Target 200k</Text>
        <Text style={{ marginTop: 6, color: '#666' }}>Rooms reward owners and users when targets met.</Text>
      </View>

      <View style={{ height: 60 }} />
    </ScrollView>
  );
}

function RechargeTab() {
  const { user, addDiamonds } = useApp();
  const packs = [500, 1200, 3000, 7500, 15000];

  return (
    <View style={{ flex: 1, padding: 12 }}>
      <Text style={styles.h2}>Recharge Diamonds</Text>
      <Text>Your balance: {user.diamonds} diamonds</Text>
      {packs.map(p => (
        <TouchableOpacity key={p} style={styles.pack} onPress={() => addDiamonds(p)}>
          <Text>Buy {p} diamonds</Text>
        </TouchableOpacity>
      ))}
      <Text style={{ marginTop: 12, color: '#666' }}>Note: This is a demo — no real payment integration.</Text>
    </View>
  );
}

function RoomsTab() {
  const { user, createRoom, rooms, joinRoom } = useApp();
  const [roomName, setRoomName] = useState('');

  return (
    <View style={{ flex: 1, padding: 12 }}>
      <Text style={styles.h2}>Rooms</Text>
      <Text>Create a room (cost 10,000 diamonds):</Text>
      <View style={{ flexDirection: 'row', marginTop: 8 }}>
        <TextInput placeholder="Room name" value={roomName} onChangeText={setRoomName} style={[styles.input, { flex: 1 }]} />
        <TouchableOpacity onPress={() => { createRoom(roomName || 'Room-' + Date.now()); setRoomName(''); }} style={[styles.btnPrimary, { marginLeft: 8 }]}>
          <Text style={styles.btnText}>Create</Text>
        </TouchableOpacity>
      </View>

      <Text style={{ marginTop: 12, fontWeight: '700' }}>Open Rooms</Text>
      <FlatList data={rooms} keyExtractor={r => r.id} renderItem={({ item }) => (
        <View style={styles.roomRow}>
          <Text style={{ fontWeight: '700' }}>{item.name}</Text>
          <Text>Owner: {item.owner}</Text>
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity style={[styles.smallBtn]} onPress={() => joinRoom(item.id)}>
              <Text>Join</Text>
            </TouchableOpacity>
          </View>
        </View>
      )} />
    </View>
  );
}

function ProfileTab() {
  const { user, buySvip, logout } = useApp();
  const svipPrices = { 1: 1200, 2: 3000, 3: 7500, 4: 15000 };
  return (
    <View style={{ flex: 1, padding: 12 }}>
      <Text style={styles.h2}>Profile</Text>
      <Text>Name: {user.name}</Text>
      <Text>Diamonds: {user.diamonds}</Text>
      <Text>Beans: {user.beans}</Text>
      <Text>SVIP level: {user.svip}</Text>

      <Text style={{ marginTop: 12, fontWeight: '700' }}>Buy SVIP</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {Object.entries(svipPrices).map(([lvl, price]) => (
          <TouchableOpacity key={lvl} style={styles.svipBtn} onPress={() => buySvip(Number(lvl), price)}>
            <Text>SVIP {lvl} - {price}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity onPress={logout} style={[styles.btnDanger, { marginTop: 12 }]}>
        <Text style={styles.btnText}>Logout (reset demo)</Text>
      </TouchableOpacity>
    </View>
  );
}

function AdminTab() {
  const { user, users, giveSvipTo, banUser } = useApp();
  if (!user.isAdmin) return (
    <View style={styles.containerCenter}><Text>You are not admin.</Text></View>
  );
  return (
    <ScrollView style={{ flex: 1, padding: 12 }}>
      <Text style={styles.h2}>Admin Panel</Text>
      <Text style={{ fontWeight: '700' }}>Users</Text>
      {users.map(u => (
        <View key={u.id} style={styles.userRow}>
          <Text>{u.name} ({u.id}) - D:{u.diamonds} SVIP:{u.svip}</Text>
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity style={styles.smallBtn} onPress={() => giveSvipTo(u.id, Math.min(10, u.svip + 1))}><Text>Give SVIP</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: '#ffcccc' }]} onPress={() => banUser(u.id)}><Text>Ban</Text></TouchableOpacity>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

export default function App() {
  const [user, setUser] = useState(initialUser);
  const [loggedIn, setLoggedIn] = useState(false);
  const [tab, setTab] = useState('home');
  const [rooms, setRooms] = useState([]);
  const [users, setUsers] = useState([initialUser]);

  useEffect(() => {
    // keep users list in sync
    setUsers(prev => {
      const exists = prev.find(u => u.id === user.id);
      if (exists) return prev.map(p => p.id === user.id ? user : p);
      return [...prev, user];
    });
  }, [user]);

  function addDiamonds(amount) {
    setUser(prev => ({ ...prev, diamonds: prev.diamonds + amount }));
    Alert.alert('Purchased', `Added ${amount} diamonds (demo).`);
  }

  function buySvip(level, price) {
    if (user.diamonds < price) return Alert.alert('Not enough diamonds');
    setUser(prev => ({ ...prev, diamonds: prev.diamonds - price, svip: Math.max(prev.svip, level) }));
    Alert.alert('SVIP Purchased', `SVIP ${level} granted.`);
  }

  function createRoom(name) {
    const cost = 10000; // demo
    if (user.diamonds < cost) return Alert.alert('Not enough diamonds to create room');
    const room = { id: 'room_' + Date.now(), name, owner: user.name, creatorId: user.id };
    setRooms(prev => [room, ...prev]);
    setUser(prev => ({ ...prev, diamonds: prev.diamonds - cost }));
    Alert.alert('Room created', `${name} created.`);
  }

  function joinRoom(roomId) {
    const r = rooms.find(r => r.id === roomId);
    if (!r) return Alert.alert('Room not found');
    Alert.alert('Joined', `You joined ${r.name} (demo).`);
  }

  function sendGift(amount) {
    if (user.diamonds < amount) return Alert.alert('Not enough diamonds');
    setUser(prev => ({ ...prev, diamonds: prev.diamonds - amount, beans: prev.beans + Math.floor(amount * 0.1), levelExp: prev.levelExp + Math.floor(amount * 0.05) }));
    Alert.alert('Gift sent', `Spent ${amount} diamonds. Congrats!`);
  }

  function giveSvipTo(userId, level) {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, svip: level } : u));
    if (user.id === userId) setUser(prev => ({ ...prev, svip: level }));
    Alert.alert('SVIP', `User ${userId} set to SVIP ${level}`);
  }

  function banUser(userId) {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, banned: true } : u));
    Alert.alert('Banned', `${userId} marked as banned (demo).`);
  }

  function logout() {
    setUser({ ...initialUser, id: 'user_' + Math.floor(Math.random() * 10000) });
    setLoggedIn(false);
    setRooms([]);
  }

  const ctx = {
    user, setUser, users, rooms, addDiamonds, buySvip, createRoom, joinRoom, sendGift, giveSvipTo, banUser, logout,
  };

  if (!loggedIn) {
    return (
      <AppContext.Provider value={ctx}>
        <SafeAreaView style={{ flex: 1 }}>
          <LoginScreen />
          <View style={{ padding: 12 }}>
            <TouchableOpacity onPress={() => setLoggedIn(true)} style={styles.btnPrimary}><Text style={styles.btnText}>Skip Login (Demo)</Text></TouchableOpacity>
          </View>
        </SafeAreaView>
      </AppContext.Provider>
    );
  }

  return (
    <AppContext.Provider value={ctx}>
      <SafeAreaView style={{ flex: 1 }}>
        <TopBar />
        {tab === 'home' && <HomeTab />}
        {tab === 'recharge' && <RechargeTab />}
        {tab === 'rooms' && <RoomsTab />}
        {tab === 'profile' && <ProfileTab />}
        {tab === 'admin' && <AdminTab />}

        <View style={styles.tabbar}>
          <TouchableOpacity onPress={() => setTab('home')} style={styles.tabBtn}><Text>Home</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => setTab('recharge')} style={styles.tabBtn}><Text>Recharge</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => setTab('rooms')} style={styles.tabBtn}><Text>Rooms</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => setTab('profile')} style={styles.tabBtn}><Text>Profile</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => setTab('admin')} style={styles.tabBtn}><Text>Admin</Text></TouchableOpacity>
        </View>
      </SafeAreaView>
    </AppContext.Provider>
  );
}

const styles = StyleSheet.create({
  containerCenter: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 16 },
  h1: { fontSize: 22, fontWeight: '800', marginBottom: 12 },
  h2: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  h3: { fontSize: 16, fontWeight: '700' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 8, marginTop: 8, backgroundColor: '#fff' },
  btnPrimary: { backgroundColor: '#007bff', padding: 10, borderRadius: 8, alignItems: 'center' },
  btnDanger: { backgroundColor: '#e74c3c', padding: 10, borderRadius: 8, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '700' },
  topbar: { flexDirection: 'row', justifyContent: 'space-between', padding: 12, borderBottomWidth: 1, borderColor: '#eee' },
  action: { backgroundColor: '#f1f1f1', padding: 10, borderRadius: 8, marginTop: 8 },
  pack: { backgroundColor: '#fff', padding: 12, marginTop: 8, borderRadius: 8, borderWidth: 1, borderColor: '#eee' },
  roomRow: { padding: 12, borderBottomWidth: 1, borderColor: '#eee', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  smallBtn: { padding: 6, backgroundColor: '#ddd', borderRadius: 6, marginLeft: 6 },
  svipBtn: { padding: 8, backgroundColor: '#fff', borderColor: '#ddd', borderWidth: 1, margin: 6, borderRadius: 6 },
  tabbar: { flexDirection: 'row', justifyContent: 'space-around', padding: 12, borderTopWidth: 1, borderColor: '#eee' },
  tabBtn: { padding: 8 },
  userRow: { padding: 10, borderBottomWidth: 1, borderColor: '#eee', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
});
